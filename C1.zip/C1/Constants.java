public class Constants{
  public static final String OBSLUGA ="OBSLUGA";
  public static final String KONIEC = "KONIEC*";
  public static final int length = 7;
}
